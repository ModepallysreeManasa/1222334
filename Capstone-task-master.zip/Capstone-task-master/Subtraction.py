class Subtraction:
    def __init__(self):
        print("Subtraction:")
        
    def operation(self, a, b):
        res = int(a)-int(b)
        print("Subtraction result:" + str(res))
        
        