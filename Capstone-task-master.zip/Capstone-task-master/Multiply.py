class Multiply:
    def __init__(self):
        print("Multiply object created")

    def operation(self, a, b):
        res = int(a)*int(b)
        print("Multiplication of a and b:"+str(res))
        
