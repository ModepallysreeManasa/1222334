class Division:
    def __init__(self):
        print("Division object created")
        
    def operation(self, a, b):
        res = int(a)/int(b)
        print("Division of a and b:"+str(res))
